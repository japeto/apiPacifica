import * as Colors from './colors';
import Style from './style';

export {
	Colors,
	Style
}